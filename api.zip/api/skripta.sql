create database aeskericic_19 default character set utf8;
use aeskericic_19;
create table ontologija_projekcija(
    sifra int not null primary key auto_increment,
    film varchar(255) not null,
    zanr varchar(255) not null,
    mjesto varchar(255) not null,
    nastao int not null,
    prodaneKarte int not null,
    vrijeme varchar(255) not null
);
