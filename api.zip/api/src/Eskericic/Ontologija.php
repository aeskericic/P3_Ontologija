<?php

namespace Eskericic;

/**
 * @Entity @Table(name="ontologija_projekcija")
 **/


class Ontologija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $film;

    /**
    * @Column(type="string")
    */
    private $zanr;

    /**
    * @Column(type="string")
    */
    private $mjesto;

    /**
    * @Column(type="integer")
    */
    private $nastao;

    /**
    * @Column(type="integer")
    */
    private $prodaneKarte;

    /**
    * @Column(type="string")
    */
    private $vrijeme;

  public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

  public function getFilm(){
		return $this->film;
	}

	public function setFilm($film){
		$this->film = $film;
	}

  public function getZanr(){
    return $this->zanr;
  }

  public function setZanr($zanr){
		$this->zanr = $zanr;
	}

  public function getMjesto(){
  	return $this->mjesto;
  }

  public function setMjesto($mjesto){
		$this->mjesto = $mjesto;
	}

  public function getNastao(){
    return $this->nastao;
  }

  public function setNastao($nastao){
    $this->nastao = $nastao;
  }

  public function getProdaneKarte(){
    return $this->prodaneKarte;
  }

  public function setProdaneKarte($prodaneKarte){
    $this->prodaneKarte = $prodaneKarte;
  }

  public function getVrijeme(){
    return $this->vrijeme;
  }

  public function setVrijeme($vrijeme){
    $this->vrijeme = $vrijeme;
  }

  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}



?>
