<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Eskericic\Ontologija;
use Composer\Autoload\ClassLoader;

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Eskericic\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});


Flight::route('GET /tablica', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('http://oziz.ffos.hr/nastava20192020/aeskericic_19/ontologija/projekcija_Eskericic_ver2.rdf');

    foreach ($foaf->resources() as $resource) {

      $url = parse_url($resource);
      $resourceTip = str_replace('_', ' ', $url["fragment"]);

      if(is_numeric($resourceTip))
      {
        $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/aeskericic/projekcija#URI_filma>'));
        $film = str_replace('_', ' ', $url["fragment"]);
        $url = parse_url($foaf->get($resource, '<http://oziz.ffos.hr/tsw2/aeskericic/projekcija#URI_zanra>'));
        $zanr = str_replace('_', ' ', $url["fragment"]);
        $mjesto = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw1/2015/11/8/nf-ontologija#mjestoOdrzavanja>');
        $nastao = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw1/2015/11/8/nf-ontologija#jeNastao>');
        $prodaneKarte = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw1/2015/11/8/nf-ontologija#prodaneKarte>');
        $vrijeme = ''.$foaf->get($resource, '<http://oziz.ffos.hr/tsw1/2015/11/8/nf-ontologija#vrijeme>');

        $ontologija = new Ontologija();
        $ontologija->setPodaci(Flight::request()->data);

        $ontologija->setFilm($film);
        $ontologija->setZanr($zanr);
        $ontologija->setMjesto($mjesto);
        $ontologija->setNastao($nastao);
        $ontologija->setProdaneKarte($prodaneKarte);
        $ontologija->setVrijeme($vrijeme);

        $doctrineBootstrap = Flight::entityManager();
        $em = $doctrineBootstrap->getEntityManager();

        $em->persist($ontologija);
        $em->flush();
      }
    }

  echo "Unos tablice je uspješan.";

});

Flight::route('GET /search/@film', function($film){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Eskericic\Ontologija');
  $zapisi = $repozitorij->createQueryBuilder('p')
                        ->where('p.film LIKE :film')
                        ->setParameter('film', '%'.$film.'%')
                        ->getQuery()
                        ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Eskericic', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();
